﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float speed = 0;
    Rigidbody Playerrigidbody;
    public int Score = 0;
    public int Goal = 0;
    public Text Txt_Score;

    private int nextSceneToLoad;

    // Start is called before the first frame update
    void Start()
    {
        Playerrigidbody = GetComponent<Rigidbody>();
        nextSceneToLoad = SceneManager.GetActiveScene().buildIndex + 1;
    }

    // Update is called once per frame
    void Update()
    {
        if(Score >= Goal)
        {
            SceneManager.LoadScene(nextSceneToLoad);
        }
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        Playerrigidbody.AddForce(movement * speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "PickUp")
        {
            Destroy(other.gameObject);
            Score++;
            Txt_Score.text = "Coins Collected : " + Score;
        }

        if(other.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("GameLose");
        }
    }
}
